//c = ((a - b)/2)^2 + h^2
//H = h/ sqrt(1 - (h/c)^2)
//cornC = Math.arcsin(h/c)
//diag = 180 - 2*cornC
//p = c*2 + a + b;

//h = 3.46
//alpha = 60
function calculate(data) {

    data.input1.style = '';
    data.input2.style = '';
    data.input3.style = '';
    /* читаем входные данные */
    let error = document.getElementById('error');
    error.innerHTML = '';
    
    let a = +data.input1.value;
    let b = +data.input2.value;
    let h = +data.input3.value;
    
    
    if(a <= 0 || b <=0 || h <=0)
    {   
        if(a<= 0)
            {data.input1.style = 'border-color: red';}
        if(b <= 0)
            {data.input2.style = 'border-color: red';}
        if(h <= 0)
            data.input3.style = 'border-color: red';
        if(a > b)
            {
                data.input1.style = 'border-color: red';
                data.input2.style = 'border-color: red';
            }
        let block = document.getElementById('error');
        
        block.innerHTML = 'Неверный ввод значений';
        block.style.color = 'red';
        
        return true;
        
    }
    let c, H, cornC, p , diag;
    /* находим на странице элемент для вывода данных */
    let output = document.getElementById('output');
    /* заносим в него абзац с подписью */
    output.innerHTML = "<p>Результат:</p>";
   
    if (data.task1.checked) {
    if(a == b)
    {
        diag = 180 - 2*90;
         p = h*2 + a + b;
         H = a;
         c = a;
    }    
    else{
     c = Math.sqrt(((b - a)/2)**2 + h**2);
     H = h/ Math.sqrt(1 - (h/c)**2);
     z = (b - a)/(2*c);
     cornC = Math.round(Math.acos(z) * 180 / Math.PI);
     diag = 180 - 2*cornC;
     p = c*2 + a + b;
    }
    
    let newElement1 = document.createElement('p');
    let newElement2 = document.createElement('p');
    let newElement3 = document.createElement('p');
    let newElement4 = document.createElement('p');

    
    newElement1.innerHTML = "Боковые стороны = " + Math.round(c*100)/100;
    newElement2.innerHTML = "Высота к боковой стороне = " + Math.round(H*100)/100;
    newElement3.innerHTML = "Угол между диагоналями = " + Math.round(diag * 100) / 100;
    newElement4.innerHTML = "Периметр = " + Math.round(p * 100) / 100;
    if(data.task3.checked)
        output.appendChild(newElement1);
    if(data.task4.checked)
        output.appendChild(newElement2);
    if(data.task5.checked)
        output.appendChild(newElement3);
    if(data.task6.checked)
        output.appendChild(newElement4);
    }
    else if(data.task2.checked){
        if(h > 90){
            error.innerHTML = 'угол больше 90';
            return true;
        }
    
        if(a == b && h == 90){
            diag = 180 - 2*h;
            let z = a/ Math.cos(45*Math.PI/180);
            c = Math.sqrt(z**2+z**2)
            p = c*2 + a*2;
            H = a;
    }
    else if(a == b && h != 90)
    {
        error.innerHTML = 'Неверный угол';
        error.style.color = 'red';
        data.input3.style = 'border-color: red';
    }
    else{
    c = ((b - a)/2)/Math.cos(h* Math.PI / 180);
    let height = Math.sqrt(c**2 -  ((b - a)/2)**2);
        
     H = height/ Math.sqrt(1 - (height/c)**2);
    diag = 180 - 2*h;
     p = c*2 + a + b;
    }
    
    let newElement1 = document.createElement('p');
    let newElement2 = document.createElement('p');
    let newElement3 = document.createElement('p');
    let newElement4 = document.createElement('p');

    
    newElement1.innerHTML = "Боковые стороны = " + Math.round(c*100)/100;
    newElement2.innerHTML = "Высота к боковой стороне = " + Math.round(H*100)/100;
    newElement3.innerHTML = "Угол между диагоналями = " + Math.round(diag * 100) / 100;
    newElement4.innerHTML = "Периметр = " + Math.round(p * 100) / 100;

    if(data.task3.checked)
        output.appendChild(newElement1);
    if(data.task4.checked)
        output.appendChild(newElement2);
    if(data.task5.checked)
        output.appendChild(newElement3);
    if(data.task6.checked)
        output.appendChild(newElement4);
    }
    return true;
   }
   
   function changePict(data)
    {
        if(data.task2.checked)
        {
            let img = document.getElementsByTagName('img');
            img[0].setAttribute('src', 'pict2.png');
            let element = document.getElementById('alpha');
            element.childNodes[0].nodeValue = '&alpha; = ';
            data.input3.setAttribute('max', 89);
            data.input3.setAttribute('min', 1);
        }
        else
        {
            let img = document.getElementsByTagName('img');
            img[0].setAttribute('src', 'pict1.png');
            let element = document.getElementById('alpha');
            element.childNodes[0].nodeValue = 'h = ';
            data.input3.setAttribute('max', 200);
            data.input3.setAttribute('min', 1);
        }
        return true;
    }
    function clearForm(data){
       data.input1.value = '';
       data.input2.value = '';
       data.input3.value = '';

    }
   