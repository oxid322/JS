// устанавливаем соответствие между полями формы и столбцами таблицы
let correspond = {
    "Имя": "hero",
    "Атрибут": "atribute",
    "Роль": "role",
    "Атака": ['avrAtackFrom', 'avrAtackTo'],
    "Броня": ['armorFrom','armorTo'],
    "Здоровье": ['hpFrom','hpTo'],
   }

function dataFilter(dataForm){

    let dictFilter = {};
    // перебираем все элементы формы с фильтрами
   
    for(let j = 0; j < dataForm.elements.length - 1; j++) {
    // выделяем очередной элемент формы
        let item = dataForm.elements[j];
   
    // получаем значение элемента
        let valInput = item.value;
        console.log(item.id.indexOf('From'));
        console.log(item.id.indexOf('To'));
    // если поле типа text - приводим его значение к нижнему регистру
        if (item.type == "text" && (item.id.indexOf('From') == -1 && item.id.indexOf('To') == -1)) {
            valInput = valInput.toLowerCase();
        }
        else if(item.type == "text" && (item.id.indexOf('From') !== -1 || item.id.indexOf('To') !== -1))
            {
                
                
                if(item.id.indexOf("From") !== -1 && valInput == '')
                {
                    
                    valInput = Number.NEGATIVE_INFINITY;
                }
                else if(item.id.indexOf("To") !== -1 && valInput == '')
                {
                    valInput = item.id.indexOf("To")
                    valInput = Number.POSITIVE_INFINITY;
                }
                else{
                    valInput = +valInput;
                }

                
            }
    /* самостоятельно обработать значения числовых полей:
    - если в поле занесено значение - преобразовать valInput к числу;
    - если поле пусто и его id включает From - занести в valInput
    -бесконечность
    
    - если поле пусто и его id включает To - занести в valInput
    +бесконечность
    */
    // формируем очередной элемент ассоциативного массива
       
        dictFilter[`${item.id}`] = valInput;
        }
        return dictFilter;
   }

function filterTable(data, idTable, dataForm){

    // получаем данные из полей формы
        let datafilter = dataFilter(dataForm);
   
    // выбираем данные соответствующие фильтру и формируем таблицу из них
        let tableFilter = data.filter(item => {
   
            let result = true;
   
    // строка соответствует фильтру, если сравнение всех значения из input
    // со значением ячейки очередной строки - истина
            for(let key in item) {
                if(result == false)
                    return false
   
                let val = item[key];
   
                 // текстовые поля проверяем на вхождение
                if (!isFinite(val) || isNaN(val)) {
                    val = item[key].toLowerCase();
                    result &&= val.indexOf(datafilter[correspond[key]]) !== -1;
                    
                }
                // самостоятельно проверить числовые поля на принадлежность интервалу
                else
                {
                    val = +val;
                    result = (val>= datafilter[correspond[key][0]]) && (val <= datafilter[correspond[key][1]]);      
                }
            }
            return result;
             });
    // создать и вызвать функцию, которая удаляет все строки таблицы с id=idTable
    document.getElementById(idTable).innerHTML = '';
    
    // показать на странице таблицу с отфильтрованными строками
        createTable(tableFilter, idTable);
   }

   function createTable (data, idTable){
    // находим таблицу
    let table = document.getElementById(idTable);
    // формируем заголовочную строку из ключей нулевого элемента массива
    let tr = document.createElement('tr');
    for(key in data[0]) {
        let th = document.createElement('th');
        th.innerHTML = key;
        tr.append(th);
    }
    table.append(tr);
    // самостоятельно сформировать строки таблицы на основе массива data
    data.forEach((item) => {
        let tr1 = document.createElement('tr');
         // создать новую строку таблицы tr
        // перебрать ключи очередного элемента массива
        // создать элемент td
        // занести в него соответствующее значение из массива
        // добавить элемент td к строке
        // строку добавить в таблицу
        for(let key in item)
        {
            let td = document.createElement('td')
            td.innerHTML = item[key];
            tr1.append(td);
        }
        table.append(tr1);
        
    });
    }

function createOption(str, val)
{
    let item = document.createElement('option');
    item.text = str;
    item.value = val;
    return item;
}

function setSortSelect(head, sortSelect)
{
    sortSelect.append(createOption('Нет', 0));
    
    for(let i in head)
    {
        sortSelect.append(createOption(head[i], Number(i)+1));
    }
}

function setSortSelects(data, dataForm)
{
    let head = Object.keys(data);

    let allSelect = dataForm.getElementByTagName('select')

    for(let j = 0; j < allSelect.length; j++)
    {
        setSortSelect(head, allSelect[j]);
    }
}
function createSortArr(data){
    let sortArr = [];
   
    let sortSelects = data.getElementsByTagName('select');
   
    for (let i = 0; i < sortSelects.length; i++) {
   
    // получаем номер выбранной опции
        let keySort = sortSelects[i].value;
    // в случае, если выбрана опция Нет, заканчиваем формировать массив
    if (keySort == 0) {
        break;
    }
    // получаем номер значение флажка для порядка сортировки
    // имя флажка сформировано как имя поля SELECT и слова Desc
    let desc = document.getElementById(sortSelects[i].id + 'Desc').checked;
        sortArr.push({column: keySort - 1, order: desc});
    }
    return sortArr;
}

function sortTable(idTable, data)
{
    let sortArr = createSortArr(data);

 // сортировать таблицу не нужно, во всех полях выбрана опция Нет
    if (sortArr.length === 0) {
        return false;
    }
 //находим нужную таблицу
    let table = document.getElementById(idTable);
 // преобразуем строки таблицы в массив
    let rowData = Array.from(table.rows);

 // удаляем элемент с заголовками таблицы
    rowData.shift();

 //сортируем данные по возрастанию по всем уровням сортировки

    rowData.sort((first, second) => {
        for(let i in sortArr) 
            {
                let key = sortArr[i].column;

                if(sortArr[i].order)
                {
                    if (first.cells[key].innerHTML < second.cells[key].innerHTML) {
                        return 1;
                        } else if (first.cells[key].innerHTML > second.cells[key].innerHTML){
                        return -1;}
                }
                else
                {
                    if (first.cells[key].innerHTML > second.cells[key].innerHTML) {
                    return 1;
                    } else if (first.cells[key].innerHTML < second.cells[key].innerHTML){
                    return -1;}
                }
            }
            return 0;
    });

 //выводим отсортированную таблицу на страницу
    table.innerHTML = table.rows[0].innerHTML;

    rowData.forEach(item => {
    table.append(item);
    });
}

function clearFilter(srcData, dataForm)
{
    let table = document.getElementById('main-table')
    table.innerHTML = '';

    createTable(srcData, 'main-table');
    let textInput = document.getElementsByTagName('input');
    for(let i in textInput)
    {
        if(textInput[i].type == 'text')
        {
            textInput[i].value = '';
        }
    }
}

function clearSort(srcData, dataForm)
{
    let table = document.getElementById('main-table')
    table.innerHTML = '';

    createTable(srcData, 'main-table');

    let select = document.getElementsByTagName('select');
    for(let i in select)
    {
        select[i].value = 0;
    }
}

function deleteElem(dataForm, selectData)
{
    hide(dataForm);
    let first = document.getElementById('firstFields');
    let sec = document.getElementById('secondFields');
    let third = document.getElementById('thirdFields');

    let valfirst = first.value;
    let valsec = sec.value;
    if(!+valfirst)
        {
            sec.innerHTML = '';
            third.innerHTML = '';
            createSelect(selectData, 'secondFields');
            createSelect(selectData, 'thirdFields');
            return 0;
        }
        else if(!+valsec)
        {
            third.innerHTML = '';
            createSelect(selectData, 'thirdFields');
        }
    if(+valfirst && !+valsec){
        let a = sec.querySelector(`[value='${valfirst}']`);
        let b = third.querySelector(`[value='${valfirst}']`);
        a.remove();
        b.remove();

    }
    else if(!+valfirst && !+valsec)
    {
        sec.innerHTML = '';
        createSelect(selectData, 'secondFields');
    }
    if(+valsec)
    {
        let a = third.querySelector(`[value='${valsec}']`);
        a.remove();
    }
    return 1;
}

function createSelect(selectData, idSelect)
{
    let select = document.getElementById(idSelect);
    let o = document.createElement('option');
    o.value = 0;
    o.innerHTML = 'Нет';
    select.append(o);
    for(let key in selectData)
    {
        let option = document.createElement('option');
        option.value = key;
        option.innerHTML = selectData[key];
        select.append(option);
    }
    console.log(select.innerHTML);
}
function hide()
{
    let a = document.getElementById('firstFields');
    let b = document.getElementById('secondFields');
    let c = document.getElementById('thirdFields');
    if(!+a.value){
        b.style.visibility = 'hidden';
        c.style.visibility = 'hidden';
    }
    else if(+a.value && +b.value)
    {
        c.style.visibility = 'visible';
    }
    else if(+a.value && !+b.value)
    {
        b.style.visibility = 'visible';
        c.style.visibility = 'hidden';
    }
    
    
    
        
    
}