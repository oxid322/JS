document.getElementById("oy3").disabled = true;
document.getElementById("oy4").disabled = true;
document.getElementById("oy5").disabled = true;
document.getElementById("oy6").disabled = true;


d3.select("#showTable")
.on('click', function(){
    let buttonValue = d3.select(this);

    if(buttonValue.property("value") === "Показать таблицу"){

        buttonValue.attr("value", "Скрыть таблицу");

        //созднаие таблицы 
        createTable(srcData, 'main-table')
    } else {
        buttonValue.attr("value", "Показать таблицу");

        let table = document.getElementById("main-table");
        table.innerHTML = '';
    }
});

function createArrGraph(data, key, dataForm){
    groupOBj = d3.group(data, d => d[key]);

    let arrGraph = [];
    if(dataForm.oy1.checked || dataForm.oy2.checked){
        for(let entry of groupOBj){   
            let minMax = d3.extent(entry[1].map(d => d['Атака']));
            arrGraph.push({labelX: entry[0], values : minMax});    
        }    
    }
    else if(dataForm.oy3.checked || dataForm.oy4.checked){
        for(let entry of groupOBj){   
            let minMax = d3.extent(entry[1].map(d => d['Броня']));
            arrGraph.push({labelX: entry[0], values : minMax});    
        }    
    }
    else if(dataForm.oy5.checked || dataForm.oy6.checked){
        for(let entry of groupOBj){   
            let minMax = d3.extent(entry[1].map(d => d['Здоровье']));
            arrGraph.push({labelX: entry[0], values : minMax});    
        }    
    }

    return arrGraph;
}

const marginX = 50;
const marginY = 50;
const height = 600;
const width = 800;
const xAxisLength = width - marginX*2;
const yAxisLength = height - marginY*2;

let svg = d3.select("svg")
 .attr("height", height)
 .attr("width", width);

function drawGraph(data) {
    //значения по оси OX
    let isMin = false;
    let isMax = false;

    const keyX = data.ox.value;

    if(data.oy1.checked || data.oy2.checked){
        isMin = data.oy1.checked;
        isMax = data.oy2.checked;
    }
    else if(data.oy3.checked || data.oy4.checked)
    {
        isMin = data.oy3.checked;
        isMax = data.oy4.checked;
    }
    else if(data.oy5.checked || data.oy6.checked)
    {
        isMin = data.oy5.checked;
        isMax = data.oy6.checked;
    }


    const arrGraph = createArrGraph(srcData, keyX, data);

    svg.selectAll('*').remove();

    const [scX, scY] = createAxis(arrGraph, isMin, isMax);

    if(isMin){
        createChart(arrGraph, scX, scY, 0, "#da2c12")
    }
    if(isMax){
        createChart(arrGraph, scX, scY, 1, "black")
    }
    
    
}
function createAxis(data, isFirst, isSecond){
    let firstRange = d3.extent(data.map(d => d.values[0]));
    let secondRange = d3.extent(data.map(d => d.values[1]));

    let min = firstRange[0];
    let max = secondRange[1];

    let scaleX = d3.scaleBand()
                        .domain(data.map(d => d.labelX))
                        .range([0, width - 2*marginX]);

    let scaleY = d3.scaleLinear()
                        .domain([min* 0.85, max* 1.1])
                        .range([height - 2 * marginY, 0]);   
    
    let axisX = d3.axisBottom(scaleX);
    let axisY = d3.axisLeft(scaleY);

    svg.append("g")
    .attr("transform", `translate(${marginX}, ${height - marginY})`)
    .call(axisX)
    .selectAll("text")
    .style("text-anchor", "end")
    .attr("dx", "-.8em")
    .attr("dy", ".15em")
    .attr("transform", d => "rotate(-30)");

    svg.append("g")
    .attr("transform", `translate(${marginX}, ${marginY})`)
    .call(axisY);

    return [scaleX, scaleY]
}

function createChart(data, scaleX, scaleY, index, color, dataForm){
    const r = 10

    let ident = (index == 0)? -r/2 : r/2;
    if(document.getElementById('circle').checked){
        svg.selectAll(".dot")
        .data(data)
        .enter()
        .append("circle")
        .attr("r", r)
        .attr("cx", d => scaleX(d.labelX) + scaleX.bandwidth()/2)
        .attr("cy", d => scaleY(d.values[index])+ ident)
        .attr("transform", `translate(${marginX}, ${marginY})`)
        .style("fill", color);
    }
    else{
        if(color == 'black'){
            svg.selectAll(".dot")
        .data(data)
        .enter()
        .append("rect")
        .attr("x", d=> scaleX(d.labelX) + scaleX.bandwidth()/2)
        .attr("y", d=> scaleY(d.values[index]))
        .attr("width", r*2 )
        .attr("height", d=> yAxisLength - scaleY(d.values[index]))
        .attr("transform", `translate(${marginX}, ${marginY})`)
        .style("fill", color)
        .style("opacity", "50%");
        }
        else{
            svg.selectAll(".dot")
        .data(data)
        .enter()
        .append("rect")
        .attr("x", d=> scaleX(d.labelX) + scaleX.bandwidth()/2)
        .attr("y", d=> scaleY(d.values[index]))
        .attr("width", r*2 )
        .attr("height", d=> yAxisLength - scaleY(d.values[index]))
        .attr("transform", `translate(${marginX}, ${marginY})`)
        .style("fill", color);
        }
        
    }
}

function getRandomInt(min, max) {
    const minCeiled = Math.ceil(min);
    const maxFloored = Math.floor(max);
    return Math.floor(Math.random() * (maxFloored - minCeiled) + minCeiled); // The maximum is exclusive and the minimum is inclusive
  }
window.onload = drawGraph(document.forms.graphForm)

function check(data){
    if(data.oy1.checked || data.oy2.checked)
        {
            data.oy3.disabled = true;
            data.oy4.disabled = true;
            data.oy5.disabled = true;
            data.oy6.disabled = true;
        }
    else if(data.oy3.checked || data.oy4.checked)
        {
                        
            data.oy1.disabled = true;
            data.oy2.disabled = true;
            data.oy5.disabled = true;
            data.oy6.disabled = true;
        }
        else if(data.oy5.checked || data.oy6.checked)
        {
            data.oy1.disabled = true;
            data.oy2.disabled = true;
            data.oy3.disabled = true;
            data.oy4.disabled = true;
        }else{
            data.oy1.disabled = false;
            data.oy2.disabled = false;
            data.oy3.disabled = false;
            data.oy4.disabled = false;
            data.oy5.disabled = false;
            data.oy6.disabled = false;
        } 
}