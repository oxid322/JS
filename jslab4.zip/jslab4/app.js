
const width = 150;
const height = 150;

const clearBtn = d3.select("#clear");
const movebtn = d3.select("#transition");
const screenWidth = window.innerWidth;
const screenHeight = window.innerHeight;
const startX = screenWidth - 400;
const startY = screenHeight / 2;

const drawSmile = function() {
    let svg = d3.select("svg").attr("transform" , `translate(${233.4}, ${241.7})`);
       

    svg = d3
        .select("svg")
        .attr("x", startX)
        .attr("y", startY)
        .attr("width", width)
        .attr("height", height);

    // Рисуем круглое лицо
    svg.append("rect")
        .attr("y", 20)
        .attr("x", 20)
        .attr("width", width/1.5)
        .attr("height", height/1.5)
        .attr("fill", "red");

    // Рисуем глаза
    svg.append("circle")
        .attr("cx", width / 2 - 25)
        .attr("cy", height / 2 - 25)
        .attr("r", height / 12)
        .attr("fill", "black");
    
        svg.append("circle")
        .attr("cx", width / 2 - 25)
        .attr("cy", height / 2 - 25)
        .attr("r", height / 24)
        .attr("fill", "white");
        

    svg.append("circle")
        .attr("cx", width / 2 + 25)
        .attr("cy", height / 2 - 25)
        .attr("r", height / 12)
        .attr("fill", "black");

        svg.append("circle")
        .attr("cx", width / 2 + 25)
        .attr("cy", height / 2 - 25)
        .attr("r", height / 24)
        .attr("fill", "white");

    // Рисуем рот
    svg.append("rect")
        .attr("x", width / 2 - height / 4)
        .attr("y", height / 2)
        .attr("width", height / 2)
        .attr("height", height / 8)
        .attr("rx", height / 16)
        .attr("ry", height / 16)
        .attr("fill", "black");

    // Рисуем зуб
    svg.append("rect")
        .attr("x", width / 2 - height / 14)
        .attr("y", height / 1.93 - height / 50)
        .attr("width", height / 8)
        .attr("height", height / 8)
        .attr("fill", "white");

    // Рисуем брови
    svg.append("path")
        .attr(
            "d",
            `M${width / 2 - height / 4},${height / 2 - height / 4} Q${
                width / 2
            },${height / 4 - height / 12} ${width / 2 + height / 4},${
                height / 2 - height / 4
            }`
        )
        .attr("fill", "none")
        .attr("stroke", "black")
        .attr("stroke-width", height / 20);

    

    return svg;
};

document.body.onload = drawSmile();
let angle = 0;


// animateBtn.on("click", () => {
//     let pic = drawSmile();
    
//     let duration = d3.select("#duration").property("value");
//     angle += Number(d3.select("#rotation").property("value"));

//     pic.transition()
//         .duration(duration)
//         .attr("transform", `translate(${233.4}, ${241.7}) rotate(${angle % 360})`);
    
// });

clearBtn.on("click", () => {
    d3.select("svg").remove();
    d3.select("div.container").append("svg");
});

function parametricFunction(t){
    return [-2*Math.sin(2* t), -2*Math.cos(t)]
}
function moveLoop(selection, size, duration, rotation) {
    
    
    //const sideLength = size;

    //путь по параметрической функции
    let path = selection.append("path")
    .datum(d3.range(-3*Math.PI/2, Math.PI/2, 0.1)) // генерация значений
    .attr("d", d3.line()
        .x(function(t) { return parametricFunction(t)[0] * 50 + size/2; }) // Scale and position x values
        .y(function(t) { return parametricFunction(t)[1] * 50 + size/2; }) // Scale and position y values
    )
    .attr("fill", "none")
    .attr("stroke", "steelblue")
    .attr("stroke-width", 2);

    // Append a path element to the selection
    
    // .style("stroke", "black");

    // 1
    const t = selection.transition().duration(duration).ease(d3.easeLinear);

    // 2
    t.attrTween("transform", function () {
        //const i = d3.interpolateString("0,0", path.toString());
        return function (t) {
            console.log(t);
            const point = path
                .node()
                .getPointAtLength(t * path.node().getTotalLength()); //3
            return `translate( ${point.x} , ${point.y}) rotate(${t * rotation})`;
        };
    });
}

movebtn.on("click", () => {
    let pic = drawSmile();
    let duration = Number(d3.select("#duration").property("value"));
    let rotation = Number(d3.select("#rotation").property("value"));
    //console.log(duration);
    moveLoop(pic, 500, duration, rotation);
});
